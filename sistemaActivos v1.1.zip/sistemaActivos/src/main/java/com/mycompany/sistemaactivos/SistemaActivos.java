
package com.mycompany.sistemaactivos;

import interfaz.Menu;


/**
 *
 * @author ususario1
 */
public class SistemaActivos {

    public static void main(String[] args) {
        Menu ini=new Menu();
        ini.setVisible(true);
        
    }
}
